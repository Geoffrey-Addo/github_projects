//Seth Arthur
//9011633520
#include <iostream>

using namespace std;
void DisplayMenu()
{
    cout<< "ARITHMETIC COMPUTATION" << endl;
    cout<< "^^^^^^^^^^^^^^^^^^^^^^" << endl;
    cout<<"1. Addition"<<endl;
    cout<<"2. Subtraction"<<endl;
    cout<<"3. Division"<<endl;
    cout<<"4. Multiplication"<<endl;
}
int result;
int Add(int num1,int num2)
{
    result=num1 + num2;
    return result;
}
    Sub(int num1,int num2)
{
    result=num1-num2;
    return result;
}
    Div(int num1,int num2)
{
    result=num1/num2;
    return result;
}
    int Mult(int num1,int num2)
{
int result=num1*num2;
return result;
}
int main()
{
    DisplayMenu();
    int Option;
    int fnum;
    int snum;
    cout<<"Select Option(1-4): ";
    cin>>Option;
    cout<<"Enter first number";
    cin>>fnum;
    cout<<"Enter second number";
    cin>>snum;
    cout<<"\n";
    switch(Option)
{
case 1:
    cout<<"Addition is: "<<Add(fnum,snum);
    break;
case 2:
    cout<<"Subtraction is:"<<Sub(fnum,snum);
    break;
case 3:
    cout<<"Division is:"<<Div(fnum,snum);
    break;
case 4:
    cout<<"Multiplication is:"<<Mult(fnum,snum);
    break;
default:
    cout<<"Invalid Selection";

}
cout<<"\n";
cout<< "Thank you!" <<endl;

    return 0;
}
